package com.example.demodemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemodemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
